package com.msu.drivetomsu;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button drive = findViewById(R.id.driveToMsu);
        drive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onClickS();
            }
        });
    }

    @SuppressLint("QueryPermissionsNeeded")
    public void onClickS(){

        String latitude = String.valueOf(40.8666);
        String longitude = String.valueOf(74.1976);
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + latitude + "," + longitude);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        try{
            if (mapIntent.resolveActivity(this.getPackageManager()) != null) {
                startActivity(mapIntent);
            }
        }catch (NullPointerException e){
            Log.e("RHN", "onClick: NullPointerException: Couldn't open map." + e.getMessage() );
            Toast.makeText(this, "Couldn't open map", Toast.LENGTH_SHORT).show();
        }
    }
}